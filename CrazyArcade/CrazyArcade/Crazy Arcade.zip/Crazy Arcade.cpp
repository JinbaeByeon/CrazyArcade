#include <Windows.h>
#include <stdio.h>
#include "Constant.h"
#include "resource.h"
#include <time.h>

HINSTANCE hInst;
HWND hwnd;

LRESULT CALLBACK WndProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam);
void SetPos();
void Animation();
void Collision_Item();
void SetBitmap();
void Loop();



int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpszCmdLine, int nCmdShow)
{
	HWND hwnd;
	MSG msg;
	WNDCLASS WndClass;
	RECT rcWindow = { 0,0,WINDOW_WIDTH,WINDOW_HEIGHT };
	AdjustWindowRect(&rcWindow, WS_OVERLAPPEDWINDOW, false);

	hInst = hInstance;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	WndClass.lpfnWndProc = WndProc;
	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hInstance = hInstance;
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hbrBackground = CreateSolidBrush(RGB(255, 255, 255));
	WndClass.lpszMenuName = NULL;
	WndClass.lpszClassName = "Window Class Name";
	RegisterClass(&WndClass);
	hwnd = CreateWindow("Window Class Name", "Crazy Arcade", WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,
		rcWindow.right - rcWindow.left,
		rcWindow.bottom - rcWindow.top,
		NULL, NULL, hInstance, NULL);
	ShowWindow(hwnd, nCmdShow);
	UpdateWindow(hwnd);
	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}





// ����
enum Player_Position { LEFT = 3, RIGHT = 2, UP = 0, DOWN = 1 };

HDC hdc;
HBITMAP hBit;			// ���⿡ �׷��� memdc -> hdc �� ����
HBITMAP P1_Bit, P2_Bit, BGBit_InGame, ItemBit;
HBITMAP TileBit, Tile_Select, Tile_Enable, Tile_Disable;
HBITMAP Box_Bit0, Box_Bit1, Box_Bit2;
HBITMAP House_Bit0, House_Bit1, House_Bit2, TreeBit;
HBITMAP Mon1Bit, Mon2Bit;
HBITMAP Bubble, Bubble_Bomb;
RECT Crect;
RECT Player1, Player2, Item_Big[2], Item_Small[7], Portal;
RECT Monster1, Monster2;
RECT Tile[13][15], Box[13][15];
RECT P1_Bubble_UD[7], P1_Bubble_RL[7];
RECT P2_Bubble_UD[7], P2_Bubble_RL[7];
RECT Tile_Bubble1[7], Tile_Bubble2[7];


int move_Player1_LR, move_Monster1_LR, move_Monster2_LR;			// Left : -1, Right : 1 (�� �Ʒ� �̵� ��: 0)
int move_Player1_UD, move_Monster1_UD, move_Monster2_UD;			// Up : -1, Down : 1	(���� ������ �̵� �� : 0)

bool Tile_Enable_Move[13][15], isBox[13][15], MoveBox[13][15], isTree[13][15], isBush[13][15];
bool isBox1[13][15], isHouse0[13][15], isHouse1[13][15];
// ĳ���� ��Ʈ�� ����
int xPos_P1, yPos_P1;												// (0 : ��, 1 : �Ʒ�, 2 : ������, 3 : ����, 4 : �����, 5 : �ٴ�, 6 : ����)
int xPos_P2, yPos_P2;												// (0 : ��, 1 : �Ʒ�, 2 : ������, 3 : ����, 4 : �����, 5 : �ٴ�, 6 : ����)
int Mon1_X, Mon1_Y;
int Mon2_X, Mon2_Y;
int xPos_Tile;
int P1_bX[7], P1_bY[7]; //������ x,y��ǥ (���� ���� ĳ������ x�� y�� ��ǥ�� �޴´�.)
int P2_bX[7], P2_bY[7];
int xPos_Bubble;
int P1_Bubble_cnt[7], P2_Bubble_cnt[7];
int P1_Bubble_Bom[7];


BOOL P1_Bubble[7];	//�ִ� ��ź�� ���� �� �ִ� ������ 7��
BOOL P1_bOn[7];		//�������� �ʱ� ���ؼ�. ����
BOOL P2_Bubble[7];
BOOL P2_bOn[7];
BOOL KeyBuffer[256];		//1p�� 2p�� ���ÿ� Ű �Է��� �� ��
BOOL P1_Bubble_Boom[7];
BOOL P2_Bubble_Boom[7];



BOOL P1_Bubble_Flow[7];	//��ź�� �������� �˷��ִ� BOOL��
int P1_MoveResource[7];	//���ٱ� ���ҽ� 40��ŭ �̵��ϱ�.
int P1_Power;	//���ٱ� �Ŀ�(���� WM_CREATE�� �����س��� �����
BOOL P1_InBubble;
BOOL P1_Escape;
BOOL P1_Die;
HBITMAP P1_DeathBit, P1_RevivalBit, P1_InTheBubbleBit;
int pDeath;


BOOL Collision(RECT rect, int x, int y)
{
	if (rect.left <= x && x <= rect.right && rect.top <= y&&y <= rect.bottom)
		return TRUE;
	return FALSE;
}


LRESULT CALLBACK WndProc(HWND hWnd, UINT iMsg, WPARAM wParam, LPARAM  lParam)
{
	hwnd = hWnd;

	static HDC mem1dc;
	PAINTSTRUCT ps;
	HBITMAP oldBit1;

	switch (iMsg)
	{
	case WM_CREATE:
		GetClientRect(hWnd, &Crect);
		P1_Power = 5;
		// ��ǥ ����
		SetPos();
		// ��Ʈ�� �ε�
		SetBitmap();
		SetTimer(hWnd, 1, 30, NULL);
		SetTimer(hWnd, 4, 100, NULL);
		return 0;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);

		Animation();

		mem1dc = CreateCompatibleDC(hdc);
		oldBit1 = (HBITMAP)SelectObject(mem1dc, hBit);
		BitBlt(hdc, 0, 0, WINDOW_WIDTH, WINDOW_HEIGHT, mem1dc, 0, 0, SRCCOPY);
		SelectObject(mem1dc, oldBit1);
		DeleteDC(mem1dc);

		EndPaint(hWnd, &ps);
		return 0;

	case WM_KEYDOWN:
		KeyBuffer[wParam] = TRUE;
		Loop();
		InvalidateRect(hWnd, NULL, FALSE);
		SetTimer(hWnd, 5, 20, NULL);
		break;

	case WM_KEYUP:
		KeyBuffer[wParam] = FALSE;
		Loop();
		InvalidateRect(hWnd, NULL, FALSE);
		break;

	case WM_TIMER:
		switch (wParam)
		{
		case 1:
			++xPos_Bubble %= 4;
			for (int i = 0; i < 7; i++) {
				if (P1_Bubble[i] && !P1_Bubble_Boom[i]) {
					if (++P1_Bubble_cnt[i] == 30) {
						P1_Bubble_Boom[i] = TRUE;
						P1_Bubble_cnt[i] = 0;
						SetTimer(hWnd, 2, 200, NULL);
					}
				}
			}
			break;
		case 2:
			for (int i = 0; i < 7; i++) {

				if (P1_Bubble_Boom[i]) {
					P1_Bubble[i] = FALSE;
					P1_Bubble_Boom[i] = FALSE;
					P1_Bubble_Flow[i] = TRUE;

					SetTimer(hWnd, 3, 100, NULL);
				}
			}
			break;
		case 3:
			for (int i = 0; i < 7; ++i)
			{
				if (P1_Bubble_Flow[i] && ++P1_MoveResource[i] == 5)
				{
					P1_Bubble_Flow[i] = FALSE;
					P1_MoveResource[i] = 0;
				}
			}
			break;
		case 4:
			pDeath=(++pDeath % 4);
			break;
		}
		InvalidateRect(hWnd, NULL, FALSE);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	}

	return DefWindowProc(hWnd, iMsg, wParam, lParam);
}

void SetPos()
{
	// �� ��ǥ ����
	for (int i = 0; i < Tile_CountY; i++)
		for (int j = 0; j < Tile_CountX; j++) {
			Tile[i][j] = { StartX + j*Tile_CX,StartY + i*Tile_CY, StartX + (j + 1)*Tile_CX,StartY + (i + 1)*Tile_CY };
			if ((i == 0 || i == 2 || i == 4 || i == 6) && (j == 10 || j == 12 || j == 14)) {
				Tile_Enable_Move[i][j] = FALSE;
				if (rand() % 3 == 0)
					isTree[i][j] = TRUE;
				if (rand() % 3)
					isHouse0[i][j] = TRUE;
				else if (rand() % 2)
					isHouse1[i][j] = TRUE;
			}
			else if ((i == 6 || i == 8 || i == 10 || i == 12) && (j == 0 || j == 2 || j == 4)) {
				Tile_Enable_Move[i][j] = FALSE;
				if (rand() % 3 == 0)
					isTree[i][j] = TRUE;
				if (rand() % 3)
					isHouse0[i][j] = TRUE;
				else if (rand() % 2)
					isHouse1[i][j] = TRUE;
			}
			else if ((i == 1 || i == 3 || i == 5) && (j == 1 || j == 3 || j == 5)) {
				Tile_Enable_Move[i][j] = FALSE;
				if (rand() % 3 == 0)
					isTree[i][j] = TRUE;
				if (rand() % 3)
					isHouse0[i][j] = TRUE;
				else if (rand() % 2)
					isHouse1[i][j] = TRUE;
			}
			else if ((i == 7 || i == 9 || i == 11) && (j == 9 || j == 11 || j == 13)) {
				Tile_Enable_Move[i][j] = FALSE;
				if (rand() % 3 == 0)
					isTree[i][j] = TRUE;
				if (rand() % 3)
					isHouse0[i][j] = TRUE;
				else if (rand() % 2)
					isHouse1[i][j] = TRUE;
			}
			else if ((i == 1 || i == 3 || i == 9 || i == 11) && (j == 5 || j == 9)) {
				Tile_Enable_Move[i][j] = FALSE;
				if (rand() % 3 == 0)
					isTree[i][j] = TRUE;
				if (rand() % 3)
					isHouse0[i][j] = TRUE;
				else if (rand() % 2)
					isHouse1[i][j] = TRUE;
			}
			else {
				Tile_Enable_Move[i][j] = TRUE;
				if ((j != 6 && j != 7 && j != 8) &&
					!(j == 0 && (i == 0 || i == 2 || i == 11)) &&
					!(j == 1 && (i == 0 || i == 11 || i == 12)) &&
					!(j == 12 && i == 1) &&
					!(j == 13 && (i == 0 || i == 1 || i == 12)) &&
					!(j == 14 && (i == 1 || i == 10 || i == 12)) &&
					!(j == 5 && i == 7) && !(j == 9 && i == 5)) {
					Box[i][j] = { Tile[i][j].left,Tile[i][j].top - 4,Tile[i][j].right,Tile[i][j].bottom };
					isBox[i][j] = TRUE;
					if (rand() % 2)
						isBox1[i][j] = TRUE;
				}
			}
			if (((i == 1 || i == 3) && (j == 0 || j == 2 || j == 4)) ||
				((i == 2 || i == 4) && (j == 11 || j == 13)) ||
				((i == 8 || i == 10) && (j == 1 || j == 3) && (i != 10 || j != 1)) ||
				((i == 9 || i == 11) && (j == 10 || j == 12 || j == 14))) {
				MoveBox[i][j] = TRUE;
			}
		}

	// �÷��̾� ��ǥ ����
	Player1 = Tile[0][0];
	Player2 = Tile[12][14];
}

/*
1P = �̵�(����Ű), ����ź( �����̽� )
2P = �̵�(wasd) , ����ź( k )
*/
void Loop()
{
	if (KeyBuffer[VK_LEFT])
	{
		xPos_P1 = (++xPos_P1 % 4);
		yPos_P1 = LEFT;
		Player1.left -= 10;
		Player1.right -= 10;
	}
	if (KeyBuffer[VK_RIGHT])
	{
		xPos_P1 = (++xPos_P1 % 4);
		yPos_P1 = RIGHT;
		Player1.left += 10;
		Player1.right += 10;
	}
	if (KeyBuffer[VK_UP])
	{
		xPos_P1 = (++xPos_P1 % 5);
		yPos_P1 = UP;
		Player1.top -= 10;
		Player1.bottom -= 10;
	}
	if (KeyBuffer[VK_DOWN])
	{
		xPos_P1 = (++xPos_P1 % 5);
		yPos_P1 = DOWN;
		Player1.top += 10;
		Player1.bottom += 10;
	}

	if (KeyBuffer[VK_SPACE])
	{
		for (int i = 0; i < 7; ++i)
		{
			if (!P1_Bubble[i] && !P1_Bubble_Flow[i])
			{
				P1_Bubble[i] = TRUE;
				SetTimer(hwnd, 1, 100, NULL);	// ��ǳ�� �ִϸ��̼�
				for (int a = 0; a < Tile_CountY; a++)
					for (int b = 0; b < Tile_CountX; b++)
					{
						if (Collision(Tile[a][b], (Player1.right + Player1.left) / 2, Player1.top))
						{
							Tile_Bubble1[i] = Tile[a][b];
						}
					}
				break;
			}
		}
	}


	if (KeyBuffer['w'] || (KeyBuffer['W']))
	{
		xPos_P2 = (++xPos_P2 % 5);
		yPos_P2 = UP;
		Player2.bottom -= 10;
	}
	if (KeyBuffer['s'] || (KeyBuffer['S']))
	{
		xPos_P2 = (++xPos_P2 % 5);
		yPos_P2 = DOWN;
		Player2.bottom += 10;
	}
	if (KeyBuffer['a'] || (KeyBuffer['A']))
	{
		xPos_P2 = (++xPos_P2 % 4);
		yPos_P2 = LEFT;
		Player2.left -= 10;
	}
	if (KeyBuffer['d'] || (KeyBuffer['D']))
	{
		xPos_P2 = (++xPos_P2 % 4);
		yPos_P2 = RIGHT;
		Player2.left += 10;
	}
	if (KeyBuffer['K'] || KeyBuffer['k'])
	{
		for (int i = 0; i < 7; ++i)
		{
			if (!P2_Bubble[i])
			{
				P2_Bubble[i] = TRUE;
				break;
			}
		}
	}

}

void Animation()
{
	HDC mem1dc, mem2dc;
	HBITMAP oldBit1, oldBit2;
	int cnt = 0;

	if (hBit == NULL)
		hBit = CreateCompatibleBitmap(hdc, WINDOW_WIDTH, WINDOW_HEIGHT);
	mem1dc = CreateCompatibleDC(hdc);
	mem2dc = CreateCompatibleDC(mem1dc);
	oldBit1 = (HBITMAP)SelectObject(mem1dc, hBit);

	oldBit2 = (HBITMAP)SelectObject(mem2dc, BGBit_InGame);
	BitBlt(mem1dc, 0, 0, WINDOW_WIDTH, WINDOW_HEIGHT, mem2dc, 0, 0, SRCCOPY);

	// ó�� Ÿ�� O,X �׸��� (���߿� ����)
	for (int i = 0; i < Tile_CountY; i++)
		for (int j = 0; j < Tile_CountX; j++) {
			if (Tile_Enable_Move[i][j])
				SelectObject(mem2dc, Tile_Enable);
			else
				SelectObject(mem2dc, Tile_Disable);
			BitBlt(mem1dc, Tile[i][j].left, Tile[i][j].top, Tile_CX, Tile_CY, mem2dc, 0, 0, SRCCOPY);
			SelectObject(mem2dc, oldBit2);
		}

	// �⺻ �� �׸���
	for (int i = 0; i < Tile_CountY; i++)
		for (int j = 0; j < Tile_CountX; j++) {
			if (Tile_Enable_Move[i][j]) {
				SelectObject(mem2dc, TileBit);
				if (j != 6 && j != 7 && j != 8)
					xPos_Tile = cnt++ % 2;
				else if (i == 2 || i == 10)
					xPos_Tile = 6;
				else if (j == 7)
					xPos_Tile = 3;
				else if (i == 0 || i == 12)
					xPos_Tile = 4;
				else
					xPos_Tile = 2;
				// �ع��� Ÿ�� ����
				StretchBlt(mem1dc, Tile[i][j].left, Tile[i][j].top, Tile_CX, Tile_CY, mem2dc, xPos_Tile*Tile_CX, 0, Tile_CX, Tile_CY, SRCCOPY);
				// Ÿ�� �� �ڽ� ����
				if (isBox[i][j]) {
					if (MoveBox[i][j]) {
						SelectObject(mem2dc, Box_Bit0);
						TransparentBlt(mem1dc, Box[i][j].left, Box[i][j].top, Box_CX, Box_CY, mem2dc, 0, 0, Box_CX, Box_CY, TPColor);
					}
					else {
						if (isBox1[i][j])
							SelectObject(mem2dc, Box_Bit1);
						else
							SelectObject(mem2dc, Box_Bit2);
						TransparentBlt(mem1dc, Box[i][j].left, Box[i][j].top, Box_CX, Box_CY, mem2dc, 0, 0, Box_CX, Box_CY, TPColor);
					}
				}
			}
			// ������ ����, �� ����
			else {
				if (isTree[i][j]) {
					SelectObject(mem2dc, TileBit);
					StretchBlt(mem1dc, Tile[i][j].left, Tile[i][j].top, Tile_CX, Tile_CY, mem2dc, 0, 0, Tile_CX, Tile_CY, SRCCOPY);
					SelectObject(mem2dc, TreeBit);
					TransparentBlt(mem1dc, Tile[i][j].left, Tile[i][j].bottom - Tree_CY, Tree_CX, Tree_CY, mem2dc, 0, 0, Tree_CX, Tree_CY, TPColor);
				}
				else {
					if (isHouse0[i][j])
						SelectObject(mem2dc, House_Bit0);
					else if (isHouse1[i][j])
						SelectObject(mem2dc, House_Bit1);
					else
						SelectObject(mem2dc, House_Bit2);
					TransparentBlt(mem1dc, Tile[i][j].left, Tile[i][j].bottom - House_CY, House_CX, House_CY, mem2dc, 0, 0, House_CX, House_CY, TPColor);
				}
			}
		}

	// ĳ���� �׸���
	/////P1 ���� P2 �ٿ�

	if (P1_InBubble) 
	{
		SelectObject(mem2dc, P1_InTheBubbleBit);
		TransparentBlt(mem1dc, Player1.left - xGap_Char, Player1.bottom - Char_CY, Char_CX, Char_CY, mem2dc,70* pDeath, 280, Char_CX, Char_CY, TPColor);
	}
	else if (P1_Escape) 
	{
		SelectObject(mem2dc, P1_RevivalBit);
		TransparentBlt(mem1dc, Player1.left - xGap_Char, Player1.bottom - Char_CY, Char_CX, Char_CY, mem2dc, 0, 200, Char_CX, Char_CY, TPColor);
	}

	else if (P1_Die) 
	{
		SelectObject(mem2dc, P1_DeathBit);
		TransparentBlt(mem1dc, Player1.left - xGap_Char, Player1.bottom - Char_CY, Char_CX, Char_CY, mem2dc, 0, 240, Char_CX, Char_CY, TPColor);
	}

	else
	{
		SelectObject(mem2dc, P1_Bit);
		TransparentBlt(mem1dc, Player1.left - xGap_Char, Player1.bottom - Char_CY, Char_CX, Char_CY, mem2dc, xPos_P1*Char_CX, yPos_P1*Char_CY, Char_CX, Char_CY, TPColor);
		SelectObject(mem2dc, P2_Bit);
		TransparentBlt(mem1dc, Player2.left - xGap_Char, Player2.bottom - Char_CY, Char_CX, Char_CY, mem2dc, xPos_P2*Char_CX, yPos_P2*Char_CY, Char_CX, Char_CY, TPColor);
	}

	////��ǳ��(������ ��)
	SelectObject(mem2dc, Bubble);


	for (int i = 0; i < 7; i++)
		if (P1_Bubble[i])
			TransparentBlt(mem1dc, Tile_Bubble1[i].left, Tile_Bubble1[i].top, 40, 40, mem2dc, Bubble_CX*xPos_Bubble, 0, 40, 40, RGB(0, 255, 0));

	//��ǳ��(���� ��)
	SelectObject(mem2dc, Bubble_Bomb);
	for (int i = 0; i < 7; ++i)	
	{
		if (P1_Bubble_Flow[i])
		{
			TransparentBlt(mem1dc, Tile_Bubble1[i].left, Tile_Bubble1[i].top, 40, 40, mem2dc, 40 * P1_MoveResource[i], 0, 40, 40, RGB(0, 255, 0));
			TransparentBlt(mem1dc, Tile_Bubble1[i].left, Tile_Bubble1[i].top - 40 * P1_Power, 40, 40, mem2dc, 40 * P1_MoveResource[i], 40, 40, 40, RGB(0, 255, 0));
			TransparentBlt(mem1dc, Tile_Bubble1[i].left, Tile_Bubble1[i].top + 40 * P1_Power, 40, 40, mem2dc, 40 * P1_MoveResource[i], 80, 40, 40, RGB(0, 255, 0));
			TransparentBlt(mem1dc, Tile_Bubble1[i].left + 40 * P1_Power, Tile_Bubble1[i].top, 40, 40, mem2dc, 40 * P1_MoveResource[i], 120, 40, 40, RGB(0, 255, 0));
			TransparentBlt(mem1dc, Tile_Bubble1[i].left - 40 * P1_Power, Tile_Bubble1[i].top, 40, 40, mem2dc, 40 * P1_MoveResource[i], 160, 40, 40, RGB(0, 255, 0));

			for (int j = 1; j < P1_Power; ++j)
			{
				TransparentBlt(mem1dc, Tile_Bubble1[i].left, Tile_Bubble1[i].top - (40 * j), 40, 40, mem2dc, 40 * P1_MoveResource[i], 200, 40, 40, RGB(0, 255, 0));
				TransparentBlt(mem1dc, Tile_Bubble1[i].left, Tile_Bubble1[i].top + (40 * j), 40, 40, mem2dc, 40 * P1_MoveResource[i], 240, 40, 40, RGB(0, 255, 0));
				TransparentBlt(mem1dc, Tile_Bubble1[i].left + (40 * j), Tile_Bubble1[i].top, 40, 40, mem2dc, 40 * P1_MoveResource[i], 280, 40, 40, RGB(0, 255, 0));
				TransparentBlt(mem1dc, Tile_Bubble1[i].left - (40 * j), Tile_Bubble1[i].top, 40, 40, mem2dc, 40 * P1_MoveResource[i], 320, 40, 40, RGB(0, 255, 0));
			}
		}
	}




	SelectObject(mem1dc, oldBit1);
	SelectObject(mem2dc, oldBit2);
	DeleteDC(mem1dc);
	DeleteDC(mem2dc);
}

void SetBitmap()
{
	BGBit_InGame = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP_INGAME_BG));
	Tile_Enable = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP_TILE_ENABLE));
	Tile_Disable = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP_TILE_DISABLE));
	TileBit = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP_TILE));
	Box_Bit0 = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP_BOX0_M1));
	Box_Bit1 = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP_BOX1_M1));
	Box_Bit2 = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP_BOX2_M1));
	House_Bit0 = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP_HOUSE0));
	House_Bit1 = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP_HOUSE1));
	House_Bit2 = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP_HOUSE2));
	TreeBit = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP_TREE));
	P1_Bit = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP_C1));
	P2_Bit = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP_C2));
	Bubble = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP_Bubble));
	Bubble_Bomb = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP_BubbleBomb));
	P1_DeathBit = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP_C1));
	P1_RevivalBit = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP_C1));
	P1_InTheBubbleBit = LoadBitmap(hInst, MAKEINTRESOURCE(IDB_BITMAP_C1));
}

